<footer class="bg-[#5BC6BC] text-white h-16">
    <div class="max-w-full mx-auto px-6 h-full flex items-center justify-start">
        <p class="text-sm">© {{ date('Y') }} ToskaKirim. All rights reserved.</p>
    </div>
</footer>

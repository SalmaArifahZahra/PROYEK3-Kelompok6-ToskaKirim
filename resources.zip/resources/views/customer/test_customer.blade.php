@extends('layouts.layout_customer')

@section('title', 'Test Footer')

@section('content')
    <div class="text-center py-20">
        <h1 class="text-3xl font-bold text-gray-800">Tes Footer</h1>
    </div>
@endsection
